#include <cstring>
#include <omnetpp.h>

using namespace omnetpp;

/**
 * Lớp HelloNode mô phỏng logic truyền nhận gói tin cơ bản giữa nodeA và nodeB.
 */
class HelloNode : public cSimpleModule
{
  private:
    // Biến trạng thái: Bộ đếm gói tin đã gửi/nhận
    long messageCounter;

  protected:
    // Hàm khởi tạo: Bắt đầu quá trình gửi tin nhắn nếu là nodeA
    virtual void initialize() override;
    // Hàm xử lý tin nhắn: Nhận, kiểm tra điều kiện, và gửi phản hồi
    virtual void handleMessage(cMessage *msg) override;
};

// Đăng ký module với Omnet++
Define_Module(HelloNode);

void HelloNode::initialize()
{
    messageCounter = 0;
    // Nút A là nút khởi tạo
    if (strcmp("nodeA", getName()) == 0) {
        EV << "Node A: Khởi tạo gói tin 'Hello World' đầu tiên.\n";
        // Tạo tin nhắn và gửi
        cMessage *msg = new cMessage("Hello World Packet");
        send(msg, "out");
        messageCounter++;
    }
}

void HelloNode::handleMessage(cMessage *msg)
{
    // 1. In ra thông báo nhận gói tin
    EV << getName() << ": Đã nhận gói tin: '" << msg->getName() << "' (Lần thứ " << messageCounter + 1 << ").\n";

    // 2. Kiểm tra điều kiện dừng: 5 lần trao đổi (Tổng cộng 5 gói tin gửi đi)
    if (messageCounter >= 5) {
        EV << getName() << ": Đã đạt giới hạn 5 gói tin. Dừng mô phỏng.\n";
        delete msg;
        endSimulation(); // Hàm dừng mô phỏng
        return;
    }



    messageCounter++;
    EV << getName() << ": Gửi phản hồi lại. (Lần thứ " << messageCounter << ").\n";
    send(msg, "out"); // Gửi gói tin ngược lại
}
