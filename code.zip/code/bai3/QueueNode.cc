#include <omnetpp.h>

using namespace omnetpp;

// ==========================================================
// 1. SourceNode - Nút phát sinh gói tin
// ==========================================================
class SourceNode : public cSimpleModule
{
private:
    cMessage *sendMessage;

protected:
    virtual void initialize() override
    {
        sendMessage = new cMessage("DataPacket");
        // Bắt đầu gửi gói tin đầu tiên
        scheduleAt(simTime(), sendMessage);
    }

    virtual void handleMessage(cMessage *msg) override
    {
        // Gửi gói tin (dùng dup() để tạo bản sao)
        cMessage *newMsg = msg->dup();
        send(newMsg, "out");

        // Lập lịch cho gói tin tiếp theo
        scheduleAt(simTime() + par("sendInterval").doubleValue(), msg);
    }

    virtual ~SourceNode() {
        if (sendMessage)
            delete sendMessage;
    }
};
Define_Module(SourceNode);


// ==========================================================
// 2. QueueNode - Nút xử lý hàng đợi và mất gói
// ==========================================================
class QueueNode : public cSimpleModule
{
private:
    cQueue queue;
    cMessage *endProcessMsg;
    int packetsReceived;
    int packetsDropped;

protected:
    virtual void initialize() override
    {
        packetsReceived = 0;
        packetsDropped = 0;
        endProcessMsg = new cMessage("endProcess");
    }

    virtual void handleMessage(cMessage *msg) override
    {
        if (msg == endProcessMsg) {
            // Sự kiện kết thúc xử lý (Gửi gói tin đang ở đầu hàng đợi)
            if (queue.isEmpty()) {
                // Hàng đợi rỗng (IDLE)
            } else {
                // Xử lý gói tin tiếp theo
                cMessage *pkt = (cMessage*)queue.pop();
                send(pkt, "out");

                // Lập lịch cho sự kiện xử lý tiếp theo
                scheduleAt(simTime() + par("processDelay").doubleValue(), endProcessMsg);
            }
        } else {
            // Gói tin đến từ SourceNode
            packetsReceived++;
            int limit = par("queueLimit").intValue();

            if (queue.getLength() < limit) {
                // Chèn vào hàng đợi
                queue.insert(msg);

                // Bắt đầu xử lý nếu đang IDLE
                if (!endProcessMsg->isScheduled()) {
                    scheduleAt(simTime() + par("processDelay").doubleValue(), endProcessMsg);
                }
            } else {
                // Hàng đợi đã đầy => Hủy gói tin (Mất gói)
                packetsDropped++;
                delete msg;
            }
        }
    }

    virtual void finish() override
    {
        // Tính Tỷ lệ Mất gói
        double lossRate = 0.0;
        if (packetsReceived > 0) {
            lossRate = (double)packetsDropped / packetsReceived;
        }

        recordScalar("Packet_Loss_Rate", lossRate);
        recordScalar("Total_Received_at_Queue", packetsReceived);
    }

    virtual ~QueueNode() {
        if (endProcessMsg)
            cancelAndDelete(endProcessMsg);
        // Xóa tất cả các gói tin còn lại trong hàng đợi
        while (!queue.isEmpty())
            delete queue.pop();
    }
};
Define_Module(QueueNode);

// ==========================================================
// 3. SinkNode - Nút đích (Đảm bảo Class được tìm thấy)
// ==========================================================
class SinkNode : public cSimpleModule
{
protected:
    virtual void handleMessage(cMessage *msg) override
    {
        // Gói tin đến đích thành công
        EV << "SinkNode da nhan goi tin thanh cong. \n";
        delete msg;
    }
};
Define_Module(SinkNode);
