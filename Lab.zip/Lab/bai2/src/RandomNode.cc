// File: RandomNode.cc
#include <omnetpp.h>

using namespace omnetpp;

class RandomNode : public cSimpleModule
{
private:
    cMessage *selfMessage;
    int counter;

protected:
    virtual void initialize() override
    {
        counter = 0;
        selfMessage = new cMessage("Tich Tac");

        // Bắt đầu sự kiện đầu tiên ngay lập tức
        scheduleAt(simTime(), selfMessage);
    }

    virtual void handleMessage(cMessage *msg) override
    {
        if (msg == selfMessage) {
            counter++;
            EV << "Su kien tu kich hoat lan thu " << counter << " tai t=" << simTime() << "s\n";

            // Yêu cầu 4: Kiem tra dieu kien dung
            if (counter >= par("limit").intValue()) {
                EV << "Dat gioi han " << par("limit").intValue() << " su kien. Dung mo phong.\n";
                endSimulation();
                return;
            }

            // Lập lịch cho sự kiện tiếp theo
            scheduleNextEvent();

        } else {
            delete msg; // Xóa gói tin không liên quan
        }
    }

    virtual void finish() override
    {
        // Yêu cầu 4: Ghi lại tổng số sự kiện và độ trễ trung bình
        recordScalar("Tong_so_su_kien", counter);
    }

    void scheduleNextEvent()
    {
        // Yêu cầu 3: Độ trễ ngẫu nhiên (Uniform distribution từ 1s đến 5s)
        double delay = uniform(1.0, 5.0);

        // Ghi lại độ trễ ngẫu nhiên đã tạo ra
        recordScalar("Random_Delay_Value", delay);

        scheduleAt(simTime() + delay, selfMessage);
    }

    virtual ~RandomNode() {
        // Hủy và xóa selfMessage khi module bị hủy
        if (selfMessage)
            cancelAndDelete(selfMessage);
    }
};

Define_Module(RandomNode);
